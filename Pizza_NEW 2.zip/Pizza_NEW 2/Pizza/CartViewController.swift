//
//  CartViewController.swift
//  Pizza
//
//  Created by TOPS on 8/9/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class CartViewController: UIViewController,UITableViewDataSource,UITableViewDelegate
{
    @IBOutlet weak var tbl: UITableView!
    var arr = [1]

    override func viewDidLoad() {
        super.viewDidLoad()

       }
    
    @IBAction func BackButtonAction(_ sender: Any)
    {
       self.navigationController?.popViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        }
//TableView
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cartcustomcell", for: indexPath) as! cartcustomcell
        
        cell.qtystepper.addTarget(self, action: #selector(self.test), for:.valueChanged)
        
        return cell
    }
    
    @objc func test(sender:UIStepper)
    {
        let indexpath = IndexPath(row: 0, section: 0)
        let cell = tbl.cellForRow(at: indexpath) as! cartcustomcell
        
        cell.lblqty.text = "\(Int(cell.qtystepper.value))"
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
