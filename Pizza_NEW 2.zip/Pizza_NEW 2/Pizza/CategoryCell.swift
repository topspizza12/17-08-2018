//
//  CategoryCell.swift
//  Pizza
//
//  Created by mac on 16/08/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class CategoryCell: UITableViewCell {

    @IBOutlet var CatDesLbl: UILabel!
    @IBOutlet var CatTitleLabel: UILabel!
    @IBOutlet var CatImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
