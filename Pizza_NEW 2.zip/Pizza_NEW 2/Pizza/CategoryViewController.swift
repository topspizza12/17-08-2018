//
//  CategoryViewController.swift
//  Pizza
//
//  Created by TOPS on 8/9/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import SDWebImage

class CategoryViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,catdelegate
{
    @IBOutlet weak var tbl: UITableView!
    
    var finalarr : [Any] = [];
    
    var cat_id :String = "";
    
    let imgarry = ["Corn_&_Cheese","Fresh_Veggie","Paneer_Makhni"]
    let lablearray = ["Corn_&_Cheese","Fresh_Veggie","Paneer_Makhni"]
    let DetailLablearray = ["Pizza bread is a type of sandwich that is often served open-faced which consists of bread, tomato sauce, cheese and various toppings. ... ","Neapolitan is the original pizza. This delicious pie dates all the way back to 18th century in Naples, Italy.","This Pizza is created a pizza with a thick crust that had raised edges, similar to a pie, and ingredients in reverse, with slices of mozzarella lining the dough followed by meat, vegetables, and then topped with a can of crushed tomatoes."]
    

    @IBOutlet var CategoryTbl: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        let obj = catcontoller();
        obj.delgate = self;
        obj.getsubcat(cat_id: cat_id);
        
    
        
    }
    func getsubcatresp(arr: [Any]) {
        
        
        finalarr = arr;
        
        
        tbl.reloadData();
        
        
        
    }
    @IBAction func BackButtonAction(_ sender: Any)
    {
        self.navigationController?.popViewController(animated: true)
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return finalarr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        var temp = finalarr[indexPath.row] as! [String:Any];
        
        let imgurl = temp["subcat_img"] as! String;
        
        
        let cell:CategoryCell = tableView.dequeueReusableCell(withIdentifier: "CategoryCell", for: indexPath) as! CategoryCell
        
        
         cell.CatImageView?.sd_setImage(with: URL(string: imgurl), placeholderImage: UIImage(named: "placeholder.png"))
        cell.CatTitleLabel.text = temp["subcat_name"] as? String;
        
        
     //   cell.CatDesLbl.text = DetailLablearray[indexPath.row]
    
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return 150
    }

}
