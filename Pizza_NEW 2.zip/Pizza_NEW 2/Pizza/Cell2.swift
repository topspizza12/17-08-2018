//
//  Cell2.swift
//  Pizza
//
//  Created by mac on 16/08/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class Cell2: UITableViewCell {

    @IBOutlet var CollectionViewInCell2: UICollectionView!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
