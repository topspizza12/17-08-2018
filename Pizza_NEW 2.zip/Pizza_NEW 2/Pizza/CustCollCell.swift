//
//  CustCollCell.swift
//  Pizza
//
//  Created by mac on 16/08/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class CustCollCell: UICollectionViewCell
{
    @IBOutlet var ImageView: UIImageView!
    @IBOutlet var Label: UILabel!
}
