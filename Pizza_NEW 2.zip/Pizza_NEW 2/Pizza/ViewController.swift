//
//  ViewController.swift
//  Pizza
//
//  Created by TOPS on 8/7/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import ImageSlideshow
import SDWebImage
import Reachability
import MBProgressHUD
class ViewController: UIViewController,CAAnimationDelegate,UITableViewDelegate,UITableViewDataSource,UIGestureRecognizerDelegate,UICollectionViewDelegate,UICollectionViewDataSource,catdelegate
{
    var CatArr:[Any] = [];
    
    let CatLbl = ["Veg-Pizza","Garlic-Bread","Non-Veg Pizza","Burger Pizza"]
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return CatArr.count
    }
    
    
    func getcatresp(arr: [Any]) {
        
        
        MBProgressHUD.hide(for: self.view, animated: true);
        
        tbl.reloadData();
        CatArr = arr
        
          let indexpath = IndexPath(row: 1, section: 0)
        
        let cell = maintable.cellForRow(at: indexpath) as! Cell2;
        
        
        
        cell.CollectionViewInCell2.reloadData();
        
        
        
        
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell: CustCollCell = collectionView.dequeueReusableCell(withReuseIdentifier: "CustCollCell", for: indexPath) as! CustCollCell
        
        let temp = CatArr[indexPath.row] as! [String:Any];
        
        let strpath = temp["cat_img"] as! String;
        cell.ImageView.sd_setImage(with: URL(string: strpath), placeholderImage: UIImage(named: "placeholder.png"))
        
        
        
       // cell.ImageView.image = UIImage(named: CatArr[indexPath.row])
        
        
        cell.Label.text = temp["cat_name"] as? String;
        
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        if indexPath.row == 0
        {
            let nav = self.storyboard?.instantiateViewController(withIdentifier: "CategoryViewController")
            
            self.navigationController?.pushViewController(nav!, animated: true)
        }
    }
    
    var flg  = 0;
    var mainview  = UIView()
    var backgroudview = UIView();
    var tbl = UITableView();
    @IBOutlet weak var maintable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navbar();
        
        
        let reachability = Reachability()!
        
        reachability.whenReachable = { reachability in
            if reachability.connection == .wifi {
                
                
                MBProgressHUD.showAdded(to: self.view, animated: true);
                
                
                self.getcatdata();

                
                
            } else {
               
                self.getcatdata();

            }
        }
        reachability.whenUnreachable = { _ in
            print("Not reachable")
        }
        
        do {
            try reachability.startNotifier()
        } catch {
            print("Unable to start notifier")
        }
        
      
    }
    
    
    func getcatdata()  {
        
        let cntobj = catcontoller();
        cntobj.delgate = self;
        cntobj.getcat();
        
        
        
        
    }
    func navbar()  {
        
        let navbar = UINavigationBar(frame: CGRect(x: 0, y: 20, width: self.view.frame.size.width, height:  50));
        
        let navitem = UINavigationItem();
        
        let btn = UIButton(type: .custom);
        btn.frame = CGRect(x: 0, y: 0, width: 40, height: 40);
        btn.setImage(UIImage(named: "SideBar"), for: .normal);
        btn.addTarget(self, action: #selector(self.menubutton), for: .touchUpInside);
        
        let menubutton = UIBarButtonItem(customView: btn);
        navitem.leftBarButtonItem = menubutton;
        navbar.items = [navitem];
        
        self.view.addSubview(navbar);
    }
    
    func menubutton(sender:UIButton)
    {
       if flg == 0
        {
            showmenu()
        }
       else
        {
            hidemenu()
        }
    }
    
    func showmenu()
    {
        mainview = UIView(frame: CGRect(x: 0, y: 70, width: self.view.frame.size.width, height: self.view.frame.size.height-70));
        mainview.backgroundColor = UIColor.gray;
        mainview.alpha = 0.3;
        mainview.isUserInteractionEnabled = true;
        self.view.addSubview(mainview);
        
        
        tapgesture()
        
        backgroudview = UIView(frame: CGRect(x: 0, y: 70, width: 0, height: self.view.frame.size.height));
        backgroudview.backgroundColor = UIColor.gray;
        
        backgroudview.alpha = 1;
        
        tbl = UITableView(frame: CGRect(x: 0, y: 70, width: 0, height: self.view.frame.size.height-70));
        //footer remove after cell
        tbl.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: 0));
        tbl.tag = 2;
        
        tbl.dataSource = self;
        tbl.delegate = self;
        
        self.view.addSubview(tbl);
        
        
        
        //self.view.addSubview(backgroudview);
        
        UITableView.beginAnimations(nil, context: nil);
        UITableView.setAnimationDuration(0.6);
        tbl.frame = CGRect(x: 0, y: 70, width: 200, height: self.view.frame.size.height-70)
        
        UITableView.commitAnimations();
        flg = 1;
        

    }
    func hidemenu(){
        UITableView.beginAnimations(nil, context: nil);
        UITableView.setAnimationDuration(0.6);
        tbl.frame = CGRect(x: 0, y: 70, width: 0, height: self.view.frame.size.height-70)
        UIView.setAnimationDelegate(self);
        
        UIView.commitAnimations();
        
        flg = 0;

    }
    
    func swipegesture()  {
        let left_Swipe = UISwipeGestureRecognizer(target: self, action: #selector(self.swipecontoller))
        left_Swipe.direction = .left
        
        let Right_Swipe = UISwipeGestureRecognizer(target: self, action: #selector(self.swipecontoller))
        Right_Swipe.direction = UISwipeGestureRecognizerDirection.right
        
        self.view.addGestureRecognizer(left_Swipe)
        self.view.addGestureRecognizer(Right_Swipe)

    }
    func swipecontoller(sender:UISwipeGestureRecognizer)  {
        
        if sender.direction == .left {
            hidemenu()
        }
        else if sender.direction == .right {
            showmenu()
        }

    }
    
    func tapgesture()  {
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.slideout));
         tap.numberOfTapsRequired = 1;
        
        mainview.addGestureRecognizer(tap);
        
    }
    
    func slideout(sender:UITapGestureRecognizer) {
       UITableView.beginAnimations(nil, context: nil);
        UITableView.setAnimationDuration(0.6);
       tbl.frame = CGRect(x: 0, y: 70, width: 0, height: self.view.frame.size.height-70)
        UIView.setAnimationDelegate(self);
        
        UIView.commitAnimations();
    }
    
    func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
        
         mainview.removeFromSuperview();
        
    }
    
    
//TableView
    let menuarr = ["Category","Wishlist","My Cart","My Order","SignUp","MyProfile"]
    
   
    
    func numberOfSections(in tableView: UITableView) -> Int
    {
        if tableView.tag == 2 {
            
            return 2;
            
        }
        else
        {
        return 1
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if tableView.tag == 2
        {
            
            if section == 0 {
                
                return CatArr.count;
            }
            else
            {
                return menuarr.count
            }
            
            
        }
        else
        {
            return 3;
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if tableView.tag == 1
        {
            if indexPath.row == 0
            {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell12", for: indexPath) as! imgsldcustcell;
            
          cell.imgsld .setImageInputs([
            ImageSource(image: UIImage(named: "img1.jpeg")!),ImageSource(image: UIImage(named: "img2.jpeg")!),
            ImageSource(image: UIImage(named: "img3.jpeg")!),ImageSource(image: UIImage(named: "img4.jpeg")!),ImageSource(image: UIImage(named: "img5.jpg")!)
                ])
            
            cell.imgsld.slideshowInterval = 1.87
            let gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.didTap))
           cell.imgsld.addGestureRecognizer(gestureRecognizer)
        
            return cell
            }
            else if indexPath.row == 1
            {
                let cell:Cell2 = tableView.dequeueReusableCell(withIdentifier: "Cell2", for: indexPath) as! Cell2
                
                cell.CollectionViewInCell2.reloadData()
                
                return cell
            }
            else
            {
                let cell:Cell3 = tableView.dequeueReusableCell(withIdentifier: "Cell3", for: indexPath) as! Cell3
                
                cell.ImageView.image = UIImage(named: "CapsicumVeg")
                
                cell.Label.text = "Pizza-Mania"
                
                return cell
                
            }
        }
        else
        {
            
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "menucell");
            
            
            
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "menucell", for: indexPath)
            
            if  indexPath.section == 0 {
                
                var temp = CatArr[indexPath.row] as! [String:Any];
                
                cell.textLabel?.text = temp["cat_name"] as? String;
                
                let strpath = temp["cat_img"] as! String;
                
                cell.imageView?.sd_setImage(with: URL(string: strpath), placeholderImage: UIImage(named: "placeholder.png"))
                
                
            }
            else
            {
                cell.textLabel?.text = menuarr[indexPath.row]
            }
        
        
        
        return cell
        }
       
    }
    

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if tableView.tag == 1
        {
            if indexPath.row == 0
            {
                return 200
            }
            else if indexPath.row == 1
            {
                return 450
            }
            else
            {
                return 150
            }
        }
        else
        {
            return 45;
        }
        
    }
    
    
    func didTap() {
        
         let indexpath = IndexPath(row: 0, section: 0)
        
        let cell = maintable.cellForRow(at: indexpath) as! imgsldcustcell;
        
       cell.imgsld .presentFullScreenController(from: self)
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        if tableView.tag == 2
        {
            if section == 0 {
              return 150

            }
            else
            {
                return 0;
            }
            
        }
        else
        {
            return 0.001
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
    {
        
         if section == 0
         {
            let imgView = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
            
            imgView.image = UIImage.init(named: "icon.jpg")
            
            imgView.contentMode = .scaleAspectFit
            
            return imgView
        }
        else
         {
            
            let imgView = UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
            
            imgView.image = UIImage.init(named: "icon.jpg")
            
            imgView.contentMode = .scaleAspectFit
            
            return imgView
            
            
        }
        
    }
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if tableView.tag == 2
        {
            if indexPath.section == 0 {
                
                
                let temp = CatArr[indexPath.row] as! [String:Any];
                
                let catid = temp["cat_id"] as! String;
                
                
                let str = self.storyboard?.instantiateViewController(withIdentifier: "CategoryViewController") as! CategoryViewController
                
                str.cat_id = catid;
                
                
                self.navigationController?.pushViewController(str, animated: true)
                
                
                
                
            }
            else
            {
            
            
            if indexPath.row == 0
            {
                let str = self.storyboard?.instantiateViewController(withIdentifier: "CategoryViewController") as! CategoryViewController
                
                self.navigationController?.pushViewController(str, animated: true)
            }
            else if indexPath.row == 1
            {
                let str = self.storyboard?.instantiateViewController(withIdentifier: "WishlistViewController") as! WishlistViewController
                
                self.navigationController?.pushViewController(str, animated: true)
                
            }
            else if indexPath.row == 2
            {
                let str = self.storyboard?.instantiateViewController(withIdentifier: "CartViewController") as! CartViewController
                
                self.navigationController?.pushViewController(str, animated: true)
                
            }
            else if indexPath.row == 3
            {
                let str = self.storyboard?.instantiateViewController(withIdentifier: "PlaceOrderViewController") as! PlaceOrderViewController
                
                self.navigationController?.pushViewController(str, animated: true)
                
            }
            else if indexPath.row == 4
            {
                let str = self.storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as! SignUpViewController
                
                self.navigationController?.pushViewController(str, animated: true)
                
            }
            else
            {
                let str = self.storyboard?.instantiateViewController(withIdentifier: "MyProfileViewController") as! MyProfileViewController
                
                self.navigationController?.pushViewController(str, animated: true)
            }
            }
        }
    
    }
}


