//
//  cartcustomcell.swift
//  Pizza
//
//  Created by Pavan on 8/15/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class cartcustomcell: UITableViewCell {
    
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var lblqty: UILabel!
    
    @IBOutlet weak var sizesegment: UISegmentedControl!
    
    @IBOutlet weak var qtystepper: UIStepper!
    
    @IBOutlet weak var priselbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
