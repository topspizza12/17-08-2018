//
//  catcontoller.swift
//  Pizza
//
//  Created by TOPS on 8/17/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

@objc protocol catdelegate {
    
 @objc optional   func getcatresp(arr :[Any]);
    
  @objc optional  func getsubcatresp(arr:[Any]);
    
    
}
class catcontoller: NSObject {

    var delgate : catdelegate?
    
    func getcat()  {
        
        let url = URL(string: "http://localhost/topspizza/getdata.php");
        let request = URLRequest(url: url!);
        let session = URLSession.shared;
        
        
         let datatask = session.dataTask(with: request) { (data1, resp, err) in
            
            let resp = String(data: data1!, encoding: String.Encoding.utf8);
            
            print(resp);
            
            
            
            do
            {
        let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [Any];
        
                DispatchQueue.main.async {
                    
                    
                    self.delgate?.getcatresp!(arr: jsondata);
                    
                    
                    
                }
                
                
                
            }
            catch
            {
                
            }
           
            
        
            
            
            
        }
        
        datatask.resume();
        
        
        
        
    }
    
    
    func getsubcat(cat_id :String) {
        
        let url = URL(string: "http://localhost/topspizza/subcat.php?cat_id=\(cat_id)");
        let request = URLRequest(url: url!);
        let session = URLSession.shared;
        
        
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            
            let resp = String(data: data1!, encoding: String.Encoding.utf8);
            
            print(resp);
            
            
            
            do
            {
                let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [Any];
                
                DispatchQueue.main.async {
                    
                    
                    self.delgate?.getsubcatresp!(arr: jsondata);
                    
                    
                    
                    
                }
                
                
                
            }
            catch
            {
                
            }
            
            
            
            
            
            
        }
        
        datatask.resume();
        
        
        
    }
    
    
    
}
