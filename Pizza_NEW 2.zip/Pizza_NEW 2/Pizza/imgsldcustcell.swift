//
//  imgsldcustcell.swift
//  Pizza
//
//  Created by TOPS on 8/13/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
 import ImageSlideshow

class imgsldcustcell: UITableViewCell {

    @IBOutlet weak var imgsld: ImageSlideshow!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
