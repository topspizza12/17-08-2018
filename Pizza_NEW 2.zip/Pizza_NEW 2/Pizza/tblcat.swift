//
//  tblcat.swift
//  Pizza
//
//  Created by TOPS on 8/17/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class tblcat: NSObject {
    
    var cat_id :Int?
    var cat_name :String?
    var cat_img :String;
    
    init(cat_id :Int,cat_name:String,cat_img:String) {
        
        
        self.cat_id = cat_id;
        self.cat_name = cat_name;
        self.cat_img = cat_img;
        
        
    }

}
